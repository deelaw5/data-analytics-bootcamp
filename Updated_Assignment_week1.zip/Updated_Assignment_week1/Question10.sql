-- Question 10: List the top 5 actors by number of films they have appeared in (show actor full name and count)
select a.first_name, a.last_name, count(fa.film_id) as film_count
from actor a
join film_actor fa
on a.actor_id = fa.actor_id
group by 1, 2
order by film_count DESC
limit 5;



