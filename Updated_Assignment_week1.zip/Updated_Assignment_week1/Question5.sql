-- Question5: list all rentals (rental_date, return_date) along with the film title and customer name.
select c.first_name, c.last_name, f.title, r.rental_date, r.return_date
from rental r 
join customer c 
on r.customer_id = c.customer_id
join inventory i 
on r.inventory_id = i.inventory_id
join film f 
on i.film_id = f.film_id;
