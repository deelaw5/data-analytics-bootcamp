-- Question6: show each staff member's full name and the total amount of payment they have processed
select s.first_name, s.last_name, SUM(p.amount) as total_payment
from staff s 
join payment p 
on s.staff_id = p.staff_id
group by 1, 2
order by total_payment;
