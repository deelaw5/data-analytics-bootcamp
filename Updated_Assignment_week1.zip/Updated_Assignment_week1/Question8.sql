-- Question 8: For each store, show the number of inventory items it holds (include store_id and count)
select s.store_id, count(i.inventory_id) as inventory_items
from store s
join inventory i 
on s.store_id = i.store_id
group by s.store_id
order by s.store_id;
