-- Question 9: show which customers are inactive (active=FALSE) and the number of rentals they made (if any)
select c.first_name, c.last_name, c.active, count(r.rental_id) as rentals
from customer c 
join rental r 
on c.customer_id = r.customer_id
where c.active = FALSE
group by 1, 2, 3
order by rentals DESC;