-- Question7: identify films that are not rented (films in film that do not appear in rental via inventory)
select f.title, r.rental_id, r.rental_date
from film f
join inventory i 
on f.film_id = i.film_id 
join rental r 
on r.inventory_id = i.inventory_id
where r.rental_id is null;


