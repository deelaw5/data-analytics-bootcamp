SELECT * FROM actor
WHERE first_name = 'Scarlett';


