INSERT INTO rental (rental_date, inventory_id, customer_id, staff_id)
SELECT
    NOW(),
    inventory.inventory_id,
    customer.customer_id,
    staff.staff_id
FROM film
JOIN inventory ON film.film_id = inventory.film_id
JOIN customer ON customer.last_name = 'SMITH'
JOIN staff ON staff.last_name = 'Hillyer'
WHERE film.title = 'ACADEMY DINOSAUR'
LIMIT 1;


