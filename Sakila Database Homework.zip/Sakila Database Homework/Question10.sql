SELECT * FROM film_category;

SELECT AVG(length) AS average_runtime
FROM film_category;

The query returns an empty set because average running time can be calculated with length which is not available
as the table contains only the colums film_id, Category_id and last_update.