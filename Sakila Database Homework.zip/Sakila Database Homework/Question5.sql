SELECT last_name, 
COUNT(*) AS occurences
FROM actor
GROUP BY last_name
HAVING COUNT(*) > 1;


