SELECT COUNT(DISTINCT last_name) As distinct_last_name
FROM actor;


