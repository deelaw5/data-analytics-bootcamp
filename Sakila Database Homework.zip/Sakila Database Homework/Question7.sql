SELECT film.title, store.* 
FROM film
JOIN store
ON film_id = store_id
WHERE film.title = 'ACADEMY DINOSAUR'
AND store_id ='1';


