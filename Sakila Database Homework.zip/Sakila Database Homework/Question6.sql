SELECT 
    actor.first_name,
    actor.last_name,
    COUNT(film.film_id) AS most_films
FROM actor
JOIN film_actor
    ON actor.actor_id = film_actor.actor_id
JOIN film
    ON film_actor.film_id = film.film_id
GROUP BY actor.actor_id, actor.first_name, actor.last_name
ORDER BY most_films DESC;


