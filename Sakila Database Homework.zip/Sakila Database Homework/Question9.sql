SELECT film.title, rental.* 
FROM film
JOIN rental
ON film_id = rental_id
WHERE film.title = 'ACADEMY DINOSAUR';


