-- Question1: Assign a row number to each payment ordered by payment amount in descending order.
-- Display payment_id, customer_id, amount, and the row number.

select payment_id, customer_id, amount,
row_number() over(order by amount desc) as rownumber
from payment;