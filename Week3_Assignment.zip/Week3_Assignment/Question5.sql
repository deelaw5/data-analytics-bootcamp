-- Question5: For each customer, show their payment history with the previous payment amount. Display
-- customer's first_name, last_name, payment_date, amount, and previous_amount (using
-- LAG). Order by customer and payment date.

select c.first_name, c.last_name, p.payment_date, p.amount,
lag(p.amount, 1, 0) over (partition by c.customer_id order by p.payment_date) as previous_amount
from customer c
join payment p 
on c.customer_id = p.customer_id;