-- Question3: For each film category, rank films by their rental_rate from highest to lowest using
-- DENSE_RANK. Display category name, film title, rental_rate, and the rank within each
-- category.

select c.name, f.title, f.rental_rate, 
dense_rank() over(order by f.rental_rate desc) as film_rank
from film f
join film_category fc
on f.film_id = fc.film_id
join category c 
on c.category_id = fc.category_id;