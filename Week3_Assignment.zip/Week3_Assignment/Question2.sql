-- Question2: Rank all films by their rental_duration in descending order. Show film_id, title, rental_duration,
-- and the rank. Notice how films with the same rental duration receive the same rank.

select film_id, title, rental_duration,
rank() over(order by rental_duration desc) as film_rank
from film;