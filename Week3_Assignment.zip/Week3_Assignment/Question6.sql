-- Question6: Calculate the running total of payments for each customer. Use a CTE to show only
-- customers whose total payments exceed $150. Display customer name and their running total
-- at each payment.

with T1 as (select c.customer_id, c.first_name, c.last_name, p.payment_id, p.payment_date, p.amount, sum(p.amount)
over(partition by c.customer_id order by p.payment_date, p.payment_id) as running_total,
sum(p.amount) over(partition by p.customer_id) as total_payment
from customer c
join payment p
on c.customer_id = p.customer_id)
select *
from T1
having total_payment >= 150
order by first_name, last_name, payment_id;