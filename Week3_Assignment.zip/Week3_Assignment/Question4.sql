-- Question4: Find the top 3 most expensive films (by replacement_cost) in each rating category (G, PG,
-- PG-13, R, NC-17). Use a CTE to filter the window function results.

with T1 as (select title, rating, replacement_cost,
row_number() over(partition by rating order by replacement_cost desc) as most_expensive_film
from film)
select *
from T1
where most_expensive_film <= 3;