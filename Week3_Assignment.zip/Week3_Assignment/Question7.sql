-- Question7:For each store, find the films that are ranked 2nd in terms of rental count. Your query should:
-- Count how many times each film has been rented per store
-- Rank films within each store by rental count (handle ties with DENSE_RANK)
-- Use a CTE to filter only the films with rank = 2
-- Display store_id, film title, rental count, and rank

with T1 as (select f.title, i.store_id, count(r.rental_id) as rental_count
from rental r
join inventory i 
on r.inventory_id = i.inventory_id
join film f 
on f.film_id = i.film_id
join store s 
on s.store_id = i.store_id
group by 1,2),
T2 as (select *,
dense_rank() over(partition by store_id order by rental_count desc) as film_rank
from T1)
select*
from T2
where film_rank = 2;
